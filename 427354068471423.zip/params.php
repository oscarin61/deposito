<?php //Post Params 
$codigo = $_POST['codigo'];  
$nombre = $_POST['nombre'];  
$prom = $_POST['prom'];  

?>