<form id="form1" name="form1" method="post" action="POST">
<label for="codigo">Codigo</label><input type="text" name="codigo" id="codigo" />
<br class="clear" /> 
<label for="nombre">Nombre</label><input type="text" name="nombre" id="nombre" />
<br class="clear" /> 
<label for="prom">Promedio</label><input type="text" name="prom" id="prom" />
<br class="clear" /> 
<input type="submit" name="guarda" id="guarda" value="Guardar" />
<br class="clear" /> 
<input type="submit" name="borra" id="borra" value="Borrar" />
<br class="clear" /> 
</form>